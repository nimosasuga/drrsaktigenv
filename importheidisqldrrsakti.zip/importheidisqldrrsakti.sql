-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versi server:                 8.4.3 - MySQL Community Server - GPL
-- OS Server:                    Win64
-- HeidiSQL Versi:               12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Membuang struktur basisdata untuk drrsakti_db
CREATE DATABASE IF NOT EXISTS `drrsakti_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `drrsakti_db`;

-- membuang struktur untuk table drrsakti_db.batteries
CREATE TABLE IF NOT EXISTS `batteries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `branch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_mekanik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `vehicle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nopol` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `customer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sn_battery` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `battery_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `battery_year` int DEFAULT NULL,
  `category_job` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `problem_date` date DEFAULT NULL,
  `rfu_date` date DEFAULT NULL,
  `problem` text COLLATE utf8mb4_unicode_ci,
  `action` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `batteries_user_id_foreign` (`user_id`),
  KEY `batteries_customer_index` (`customer`),
  KEY `batteries_location_index` (`location`),
  KEY `batteries_serial_number_index` (`serial_number`),
  CONSTRAINT `batteries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.batteries: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.battery_install_parts
CREATE TABLE IF NOT EXISTS `battery_install_parts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `battery_id` bigint unsigned NOT NULL,
  `part_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `part_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int NOT NULL DEFAULT '1',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `no_job` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_pr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `battery_install_parts_battery_id_foreign` (`battery_id`),
  CONSTRAINT `battery_install_parts_battery_id_foreign` FOREIGN KEY (`battery_id`) REFERENCES `batteries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.battery_install_parts: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.battery_recommendations
CREATE TABLE IF NOT EXISTS `battery_recommendations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `battery_id` bigint unsigned NOT NULL,
  `part_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `part_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int NOT NULL DEFAULT '1',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `battery_recommendations_battery_id_foreign` (`battery_id`),
  CONSTRAINT `battery_recommendations_battery_id_foreign` FOREIGN KEY (`battery_id`) REFERENCES `batteries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.battery_recommendations: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.cache
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.cache: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.cache_locks
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.cache_locks: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.chargers
CREATE TABLE IF NOT EXISTS `chargers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `branch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_mekanik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `vehicle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nopol` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `customer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sn_charger` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charger_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charger_year` int DEFAULT NULL,
  `category_job` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `problem_date` date DEFAULT NULL,
  `rfu_date` date DEFAULT NULL,
  `problem` text COLLATE utf8mb4_unicode_ci,
  `action` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chargers_user_id_foreign` (`user_id`),
  KEY `chargers_customer_index` (`customer`),
  KEY `chargers_location_index` (`location`),
  KEY `chargers_serial_number_index` (`serial_number`),
  CONSTRAINT `chargers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.chargers: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.charger_install_parts
CREATE TABLE IF NOT EXISTS `charger_install_parts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `charger_id` bigint unsigned NOT NULL,
  `part_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `part_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int NOT NULL DEFAULT '1',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `no_job` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_pr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `charger_install_parts_charger_id_foreign` (`charger_id`),
  CONSTRAINT `charger_install_parts_charger_id_foreign` FOREIGN KEY (`charger_id`) REFERENCES `chargers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.charger_install_parts: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.charger_recommendations
CREATE TABLE IF NOT EXISTS `charger_recommendations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `charger_id` bigint unsigned NOT NULL,
  `part_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `part_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int NOT NULL DEFAULT '1',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `charger_recommendations_charger_id_foreign` (`charger_id`),
  CONSTRAINT `charger_recommendations_charger_id_foreign` FOREIGN KEY (`charger_id`) REFERENCES `chargers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.charger_recommendations: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.deliveries
CREATE TABLE IF NOT EXISTS `deliveries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `delivery_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `branch` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_mekanik` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pic` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partner` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `vehicle` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nopol` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `customer` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year` year DEFAULT NULL,
  `hour_meter` int unsigned DEFAULT NULL,
  `job_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DELIVERY UNIT',
  `status_unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RFU',
  `battery_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `battery_sn` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charger_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charger_sn` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trolly` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `deliveries_delivery_code_unique` (`delivery_code`),
  KEY `deliveries_user_id_foreign` (`user_id`),
  KEY `deliveries_customer_location_index` (`customer`,`location`),
  KEY `deliveries_serial_number_index` (`serial_number`),
  KEY `deliveries_status_unit_index` (`status_unit`),
  KEY `deliveries_date_index` (`date`),
  KEY `deliveries_pic_index` (`pic`),
  CONSTRAINT `deliveries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.deliveries: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.failed_jobs: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.jobs
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.jobs: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.job_batches
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.job_batches: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.job_install_parts
CREATE TABLE IF NOT EXISTS `job_install_parts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint unsigned NOT NULL,
  `part_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `part_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int NOT NULL DEFAULT '1',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `no_job` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_pr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_install_parts_job_id_foreign` (`job_id`),
  CONSTRAINT `job_install_parts_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `update_jobs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.job_install_parts: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.job_recommendations
CREATE TABLE IF NOT EXISTS `job_recommendations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint unsigned NOT NULL,
  `part_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `part_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int NOT NULL DEFAULT '1',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_recommendations_job_id_foreign` (`job_id`),
  CONSTRAINT `job_recommendations_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `update_jobs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.job_recommendations: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.migrations: ~20 rows (lebih kurang)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '0001_01_01_000000_create_users_table', 1),
	(2, '0001_01_01_000001_create_cache_table', 1),
	(3, '0001_01_01_000002_create_jobs_table', 1),
	(4, '2026_05_24_103903_create_unit_assets_table', 1),
	(5, '2026_05_24_124715_create_subscription_packages_table', 1),
	(6, '2026_05_24_124716_create_user_subscriptions_table', 1),
	(7, '2026_05_24_124717_create_payments_table', 1),
	(8, '2026_05_26_170300_create_update_jobs_table', 2),
	(9, '2026_05_26_170309_create_job_recommendations_table', 3),
	(10, '2026_05_26_170317_create_job_install_parts_table', 3),
	(11, '2026_05_27_085911_create_batteries_table', 4),
	(12, '2026_05_27_085914_create_battery_recommendations_table', 4),
	(13, '2026_05_27_085935_create_battery_install_parts_table', 4),
	(14, '2026_05_27_104953_create_chargers_table', 5),
	(15, '2026_05_27_104955_create_charger_recommendations_table', 5),
	(16, '2026_05_27_104957_create_charger_install_parts_table', 5),
	(17, '2026_05_27_000000_create_deliveries_table', 6),
	(18, '2026_05_30_000000_create_penarikans_table', 7),
	(19, '2026_05_30_010000_add_extra_battery_and_trolly_to_penarikans_table', 8),
	(20, '2026_05_30_020000_add_penarikan_asset_status_triggers', 9);

-- membuang struktur untuk table drrsakti_db.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.password_reset_tokens: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.payments
CREATE TABLE IF NOT EXISTS `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `subscription_package_id` bigint unsigned NOT NULL,
  `user_subscription_id` bigint unsigned DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'GOPAY',
  `receiver_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PT EXPROSA GLOBAL NUSANTARA',
  `receiver_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '082177212271',
  `amount` int NOT NULL,
  `payment_status` enum('waiting_payment','waiting_verification','paid','rejected','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiting_payment',
  `paid_at` timestamp NULL DEFAULT NULL,
  `verified_by` bigint unsigned DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_user_id_foreign` (`user_id`),
  KEY `payments_subscription_package_id_foreign` (`subscription_package_id`),
  KEY `payments_user_subscription_id_foreign` (`user_subscription_id`),
  KEY `payments_verified_by_foreign` (`verified_by`),
  CONSTRAINT `payments_subscription_package_id_foreign` FOREIGN KEY (`subscription_package_id`) REFERENCES `subscription_packages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_user_subscription_id_foreign` FOREIGN KEY (`user_subscription_id`) REFERENCES `user_subscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.payments: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.penarikans
CREATE TABLE IF NOT EXISTS `penarikans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `penarikan_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `branch` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_mekanik` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pic` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partner` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `vehicle` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nopol` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `customer` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year` year DEFAULT NULL,
  `hour_meter` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TARIK UNIT',
  `status_unit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RFU',
  `battery_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `battery_sn` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `battery_type_2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `battery_sn_2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charger_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charger_sn` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trolly` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trolly_2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trolly_3` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `penarikans_penarikan_code_unique` (`penarikan_code`),
  KEY `penarikans_user_id_foreign` (`user_id`),
  KEY `penarikans_customer_location_index` (`customer`,`location`),
  KEY `penarikans_serial_number_index` (`serial_number`),
  KEY `penarikans_status_unit_index` (`status_unit`),
  KEY `penarikans_date_index` (`date`),
  KEY `penarikans_pic_index` (`pic`),
  CONSTRAINT `penarikans_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.penarikans: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.sessions
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.sessions: ~3 rows (lebih kurang)
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
	('aA1FQoUV6yt716rprOsZaQ1uuvbeIe67v8HkEEgY', NULL, '192.168.1.2', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36', 'eyJfdG9rZW4iOiJKUjBXa0ZqMW9tUFM5QTJtblp3VHZ1Zm5KeXIxT0JKVEJISGJhVlN6IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTkyLjE2OC4xLjQ6ODAwMFwvbG9naW4iLCJyb3V0ZSI6ImxvZ2luIn19', 1780130460),
	('kaM21q9jyW0H5cu68pkwejyWWJbfN7OvBTqeWAhC', 51585, '192.168.1.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'eyJfdG9rZW4iOiJGVXVPWnhteUUxTnQwbjltQ2wwUEkwRzQzdXFpYmZzcmpqajJLR0ZBIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cDpcL1wvMTkyLjE2OC4xLjQ6ODAwMFwvcGVuYXJpa2FucyJ9LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTkyLjE2OC4xLjQ6ODAwMFwvcGVuYXJpa2FucyIsInJvdXRlIjoicGVuYXJpa2Fucy5pbmRleCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjo1MTU4NX0=', 1780146150),
	('WvM50bC6Z0b1zD6y5Nbq5vugYIUEMMODxuhui7Pg', 51585, '192.168.1.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'eyJfdG9rZW4iOiI5dWtBdTRCM01xSEI0anhOSVFBV3ZraVZxeGVlVmxPNkNjSzhoOVIwIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTkyLjE2OC4xLjQ6ODAwMFwvYWRtaW5cL3VzZXJzP3NlYXJjaD1yYXRyIiwicm91dGUiOiJhZG1pbi51c2Vycy5pbmRleCJ9LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6NTE1ODV9', 1780130395);

-- membuang struktur untuk table drrsakti_db.subscription_packages
CREATE TABLE IF NOT EXISTS `subscription_packages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `package_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration_months` int NOT NULL DEFAULT '1',
  `price` int NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.subscription_packages: ~3 rows (lebih kurang)
INSERT INTO `subscription_packages` (`id`, `role_name`, `package_name`, `duration_months`, `price`, `is_active`, `created_at`, `updated_at`) VALUES
	(1, 'mekanik', 'Lisensi 1 Bulan', 1, 10000, 1, '2026-05-24 05:56:05', '2026-05-24 05:56:05'),
	(2, 'koordinator', 'Lisensi 1 Bulan', 1, 15000, 1, '2026-05-24 05:56:05', '2026-05-24 05:56:05'),
	(3, 'sect_head', 'Lisensi 1 Bulan', 1, 20000, 1, '2026-05-24 05:56:05', '2026-05-24 05:56:05');

-- membuang struktur untuk table drrsakti_db.unit_assets
CREATE TABLE IF NOT EXISTS `unit_assets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `supported_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `qr_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unit_assets_serial_number_unique` (`serial_number`),
  UNIQUE KEY `unit_assets_qr_token_unique` (`qr_token`)
) ENGINE=InnoDB AUTO_INCREMENT=446 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.unit_assets: ~445 rows (lebih kurang)
INSERT INTO `unit_assets` (`id`, `supported_by`, `customer`, `location`, `branch`, `serial_number`, `unit_type`, `year`, `status`, `delivery`, `jenis_unit`, `note`, `qr_token`, `created_at`, `updated_at`) VALUES
	(1, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'CIKARANG', 'HO', 'FN976042', 'EJR120n-1150-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(2, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'TANGERANG', 'HO', '90605956', 'ERC216-1150-5250DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(3, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'BANDUNG', 'HO', 'FN947525', 'ETV 120n GE 115-962DZ', '2018', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(4, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'CIKARANG', 'HO', 'FN978041', 'ETV120n-1150-11510DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(5, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'BANDUNG', 'HO', 'FN922793', 'ETV116n-1150-9020DZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(6, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'KELAPA GADING', 'HO', 'FN956774', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(7, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'KELAPA GADING', 'HO', 'FN956775', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(8, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'BANDUNG', 'HO', 'FN930948', 'ETV116n-1150-9020DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(9, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'KELAPA GADING', 'HO', 'FN917346', 'ETV116n-1150-7700DZ', '2015', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(10, 'PT. KRN', 'PT. ANUGERAH PHARMINDO LESTARI', 'KELAPA GADING', 'HO', 'FN956773', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(11, 'PT. KRN', 'PT. ANUGRAH PHARMINDO LESTARI', 'CIKARANG', 'HO', 'FN980187', 'ETV120n-1150-11510DZ', '2021', 'RENTAL', '20/04/2026', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(12, 'PT. KRN', 'PT. AVIENT COLORANT INDONESIA', 'TANGERANG', 'HO', 'F5000390', 'EFG216kn-1150-4800DZ', '-', 'ACTIVE', '20/02/2026', 'COUNTER BALANCE', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(13, 'PT. KRN', 'PT. BAYER INDONESIA', 'CIMANGGIS', 'HO', 'FN694464', 'EKX514-1200-6000DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(14, 'PT. KRN', 'PT. BAYER INDONESIA', 'CIMANGGIS', 'HO', 'FN694463', 'EKX514-1200-6000DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(15, 'PT. KRN', 'PT. CAHAYA CITRA RIZKI', 'KARAWANG', 'HO', 'N21062013204', 'ERCBB216', '2025', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(16, 'PT. KRN', 'PT. CAKARINDO MITRA INTERNASIONAL', 'BSD TANGERANG', 'HO', 'FN985156', 'EFGBC320-1150-4800DZ', '2025', 'RENTAL', '08/12/2025', 'CB', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(17, 'PT. KRN', 'PT. CERES ( UNDER SSP )', 'BANDUNG', 'HO', 'FN951243', 'ETV120n-GE115-1151DZ', '2018', 'ACTIVE', '-', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(18, 'PT. KRN', 'PT. CHEMICO INDONESIA', 'MARUNDA', 'HO', 'F5017905', 'ETVMC320-1150-1052DZ', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(19, 'PT. KRN', 'PT. CIPTA KRIDA BAHARI', 'CILINCING', 'HO', 'FN930943', 'ETV116n-1150-9020DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(20, 'PT. KRN', 'PT. CIPTA KRIDA BAHARI', 'CILINCING', 'HO', 'FN920541', 'ETV116n-1150-9020DZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(21, 'PT. KRN', 'PT. CIPTA KRIDA BAHARI', 'CILINCING', 'HO', 'FN948934', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(22, 'PT. KRN', 'PT. CIPTA KRIDA BAHARI', 'CILINCING', 'HO', 'FN943008', 'ETV 120 - 1150 -9950DZ', '2000', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(23, 'PT. KRN', 'PT. CIPTA MAPAN LOGISTIC', 'KALIJAYA CIKARANG', 'HO', 'FN987425', 'EFGMC325-1150-4400DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(24, 'PT. KRN', 'PT. CJ LOGISTIC', 'MM2100 CIKARANG', 'HO', 'F5002853', 'ETV120ni-1350-11510DZ', '-', 'ACTIVE', '27/01/2026', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(25, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'F5023434', 'ETVMC320-1350-11510DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(26, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'F5016433', 'ETVMC320-1350-11510DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(27, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'FN957608', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(28, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'CAKUNG', 'HO', 'FN916952', 'EFG320n-1150-3300ZZ', '2015', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(29, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'F5011530', 'ETVMC320-1150-1151DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(30, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'F5024341', 'ETVMC320-1150-1151DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(31, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'F5016435', 'ETVMC320-1350-11510DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(32, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', '82830713', 'ETR335d-1067-11354DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(33, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'CAKUNG', 'HO', '82827450', 'ETR335d-1067-11430DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(34, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'F5016476', 'ETVMC320-1150-1151DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(35, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', '82830680', 'ETR335d-1067-11354DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(36, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'F5016434', 'ETVMC320-1350-11510DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(37, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'CAKUNG', 'HO', '82823242', 'ETR335d-1067-11354DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(38, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', '82830678', 'ETR335d-1067-11430DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(39, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'CAKUNG', 'HO', 'FN983697', 'EFGMB216k-1150-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(40, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', '82830679', 'ETR335d-1067-11354DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(41, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'F5011531', 'ETVMC320-1150-1151DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(42, 'PT. KRN', 'PT. DAMCO WAREHOUSING INDONESIA', 'MARUNDA', 'HO', 'F5024342', 'ETVMC320-1150-1151DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(43, 'PT. KRN', 'PT. DHL SUPPLY CHAIN MUF6', 'CIKARANG', 'HO', 'F5003148', 'ETV120n-1350-11510DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(44, 'PT. KRN', 'PT. DHL SUPPLY CHAIN MUF6', 'CIKARANG', 'HO', 'FN987118', 'ETV120n-1350-11510DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(45, 'PT. KRN', 'PT. DHL SUPPLY CHAIN MUF6', 'CIKARANG', 'HO', 'FN987119', 'ETV120n-1350-11510DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(46, 'PT. KRN', 'PT. DHL SUPPLY CHAIN MUF6', 'CIKARANG', 'HO', 'F5003671', 'ETV120n-1350-11510DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(47, 'PT. KRN', 'PT. DHL SUPPLY CHAIN MUF6', 'CIKARANG', 'HO', 'F5017915', 'ETVMC320-1150-11510DZ', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(48, 'PT. KRN', 'PT. DHL SUPPLY CHAIN MUF6', 'CIKARANG', 'HO', 'FN940950', 'ETV120N-1150-11510DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(49, 'PT. KRN', 'PT. DSV SOLUTIONS INDONESIA', 'PONDOK UNGU', 'HO', 'FN688902', 'EKX516k-1200-7500DZ', '2022', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(50, 'PT. KRN', 'PT. DSV SOLUTIONS INDONESIA', 'PONDOK UNGU', 'HO', '98117064', 'ERE225-2400-6700', '2015', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(51, 'PT. KRN', 'PT. DSV SOLUTIONS INDONESIA', 'PONDOK UNGU', 'HO', '91107527', 'ETV214-1150-9410DZ', '2016', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(52, 'PT. KRN', 'PT. DSV SOLUTIONS INDONESIA', 'PONDOK UNGU', 'HO', '91107529', 'ETV214-1150-9410DZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(53, 'PT. KRN', 'PT. DUNIA KIMIA', 'DELTA MAS CIKARANG', 'HO', 'F5000388', 'EFGMB216k-1150-4800DZ', '2022', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(54, 'PT. KRN', 'PT. DUNIA KIMIA JAYA', 'CIKARANG', 'HO', 'FN957615', 'EFG216kn-1150-4800DZ', '-', 'ACTIVE', '30/01/2026', 'COUNTER BALANCE', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(55, 'PT. KRN', 'PT. ENSEVAL PUTERA MEGATRADING', 'JAKARTA', 'HO', '90683904', 'ERC216-1150-6000DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(56, 'PT. KRN', 'PT. ENSEVAL PUTERA MEGATRADING', 'BANDUNG', 'HO', '90676919', 'ERC216-1150-5250DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(57, 'PT. KRN', 'PT. ENSEVAL PUTERA MEGATRADING', 'JAKARTA', 'HO', '90683905', 'ERC216-1150-6000DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(58, 'PT. KRN', 'PT. ENSEVAL PUTERA MEGATRADING', 'DEPOK', 'HO', '90683907', 'ERC216-1150-6000DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(59, 'PT. KRN', 'PT. GARUDAFOOD PUTRA PUTRI JAYA', 'RANCAEKEK', 'HO', 'FN951212', 'ETV120n-1150-10520DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(60, 'PT. KRN', 'PT. GARUDAFOOD PUTRA PUTRI JAYA', 'RANCAEKEK', 'HO', '90617964', 'ERC216-1150-6000DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(61, 'PT. KRN', 'PT. GARUDAFOOD PUTRA PUTRI JAYA', 'RANCAEKEK', 'HO', 'F5003048', 'EJR120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(62, 'PT. KRN', 'PT. GARUDAFOOD PUTRA PUTRI JAYA', 'BANDUNG', 'HO', 'FN930949', 'ETV116n-1150-9020DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(63, 'PT. KRN', 'PT. GARUDAFOOD PUTRA PUTRI JAYA', 'RANCAEKEK', 'HO', 'FN915085', 'EJC112-1150-2900ZT', '2015', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(64, 'PT. KRN', 'PT. GARUDAFOOD PUTRA PUTRI JAYA', 'RANCAEKEK', 'HO', 'F5000393', 'EFGMB216k-1150-4800DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(65, 'PT. KRN', 'PT. GARUDAFOOD PUTRA PUTRI JAYA', 'BANDUNG', 'HO', 'FN951216', 'ETV120n-1150-10520DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(66, 'PT. KRN', 'PT. GIVAUDAN INDONESIA', 'DEPOK', 'HO', 'FN978040', 'ETV120n-1150-6800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(67, 'PT. KRN', 'PT. GIVAUDAN INDONESIA', 'DEPOK', 'HO', 'FN924607', 'EJC112-1150-2900ZT', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(68, 'PT. KRN', 'PT. GIVAUDAN INDONESIA', 'DEPOK', 'HO', 'F5002857', 'ETV120n-GE-115-962DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(69, 'PT. KRN', 'PT. GIVAUDAN INDONESIA', 'DEPOK', 'HO', 'F5002856', 'ETV120n-GE-115-962DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(70, 'PT. KRN', 'PT. GLOBAL DISTRIBUSI PUSAKA', 'PONDOK UNGU', 'HO', '91109504', 'ETV216-1150-992DZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(71, 'PT. KRN', 'PT. GLOBAL DISTRIBUSI PUSAKA', 'PONDOK UNGU', 'HO', 'FN969007', 'ETV120n-1150-9620DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(72, 'PT. KRN', 'PT. GLOBAL DISTRIBUSI PUSAKA', 'PONDOK UNGU', 'HO', 'FN958868', 'ETV120n-1150-10520DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(73, 'PT. KRN', 'PT. GLOBAL DISTRIBUSI PUSAKA', 'PONDOK UNGU', 'HO', 'FN958889', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(74, 'PT. KRN', 'PT. GLOBAL DISTRIBUSI PUSAKA', 'PONDOK UNGU', 'HO', 'FN947528', 'ETV120n-1150-9620DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(75, 'PT. KRN', 'PT. GLOBAL DISTRIBUSI PUSAKA', 'PONDOK UNGU', 'HO', 'FN956778', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(76, 'PT. KRN', 'PT. GLOBAL DISTRIBUSI PUSAKA', 'PONDOK UNGU', 'HO', 'FN957243', 'ETV120n-1150-9620DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(77, 'PT. KRN', 'PT. GLOBAL DISTRIBUSI PUSAKA', 'PONDOK UNGU', 'HO', 'FN956777', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(78, 'PT. KRN', 'PT. GLOBAL DISTRIBUSI PUSAKA', 'PONDOK UNGU', 'HO', 'FN957224', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(79, 'PT. KRN', 'PT. GONUSA PRIMA DISTRIBUSI', 'CAKUNG', 'HO', 'F5000798', 'ETV116n-1150-7700DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(80, 'PT. KRN', 'PT. HEINZ ABC INDONESIA', 'KARAWANG', 'HO', 'F5003023', 'ERE120n-1150-6700', '2022', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(81, 'PT. KRN', 'PT. HEINZ ABC INDONESIA', 'KARAWANG', 'HO', 'FN957289', 'ERE120n-1150-6700', '2019', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(82, 'PT. KRN', 'PT. HEINZ ABC INDONESIA', 'KARAWANG', 'HO', 'F5003014', 'ERE120n-1150-6700', '2022', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(83, 'PT. KRN', 'PT. HEINZ ABC INDONESIA', 'KARAWANG', 'HO', 'F5003022', 'ERE120n-1150-6700', '2022', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(84, 'PT. KRN', 'PT. ID LOGITAMA INDONESIA', 'TANGERANG', 'HO', 'FN966648', 'ETV120n-1150-10520DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(85, 'PT. KRN', 'PT. ID LOGITAMA INDONESIA', 'TANGERANG', 'HO', 'F5004905', 'EFGMC325-1150-4700DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(86, 'PT. KRN', 'PT. KAMADJAJA - NABATI', 'MAJALENGKA', 'HO', 'F5002852', 'ETV120ni-1350-1151DZ', '2024', 'ACTIVE', '18/11/2025', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(87, 'PT. KRN', 'PT. KAMADJAJA LOGISTICS', 'KARAWANG', 'HO', 'F5000391', 'EFGMB216k-1150-4800DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(88, 'PT. KRN', 'PT. KAMADJAJA LOGISTICS', 'CILEUNGSI', 'HO', 'FN958876', 'ETV120n-1150-11510DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(89, 'PT. KRN', 'PT. KAMADJAJA LOGISTICS', 'KARAWANG', 'HO', 'F5000389', 'EFGMB216k-1150-4800DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(90, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', 'FN929340', 'ERE120n-1150-6700', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(91, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', 'FN947531', 'ETV120n-1150-11510DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(92, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', 'FN910786', 'EFG320n-1150-3300ZT', '2014', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(93, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'KARAWANG', 'HO', 'F5002855', 'ETV120ni-1150-11510DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(94, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', 'FN962260', 'EFGMC320-1150-4800DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(95, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', 'FN978939', 'EFGMB216k-G+E-115-480DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(96, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', 'FN496372', 'EFG216k-1150-4800DZ', '2015', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(97, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', '91089668', 'ETV214-1150-9920DZ', '2014', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(98, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', 'FN916631', 'ERE120n-1150-6700', '2015', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(99, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', '173B04172869J', 'AMW-INOX-540X-1150', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(100, 'PT. KRN', 'PT. KERRY INGREDIENTS INDONESIA', 'CIKARANG', 'HO', 'FN906664', 'ERE120n-1150-6700', '-', 'RENTAL', '-', 'Junior Truck', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(101, 'PT. KRN', 'PT. KINTETSU LOGISTICS INDONESIA', 'PONDOK UNGU', 'HO', 'FN956781', 'EFG320n-1150-4800DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(102, 'PT. KRN', 'PT. KINTETSU LOGISTICS INDONESIA', 'PONDOK UNGU', 'HO', 'FN946896', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(103, 'PT. KRN', 'PT. KINTETSU LOGISTICS INDONESIA', 'PONDOK UNGU', 'HO', 'FN957605', 'ETV116n-1150-9020DZ', '-', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(104, 'PT. KRN', 'PT. KOSMETIKA GLOBAL', 'DELTA SILICON', 'HO', 'FN931026', 'EFG320n-1150-4800DZ', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(105, 'PT. KRN', 'PT. KOSMETIKA GLOBAL', 'DELTA SILICON', 'HO', 'FN399416', 'EKX515k-1150-9500DZ', '2009', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(106, 'PT. KRN', 'PT. KREASI MAS INDAH', 'CIHERANG', 'HO', '91124070', 'ETM216-1150-9020DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(107, 'PT. KRN', 'PT. KREASI MAS INDAH', 'CIHERANG', 'HO', '91124069', 'ETM216-1150-9020DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(108, 'PT. KRN', 'PT. LF SERVICE', 'PONDOK UNGU', 'HO', 'F5017918', 'ETVMC320-1150-1151DZ', '2023', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(109, 'PT. KRN', 'PT. LF SERVICE', 'PONDOK UNGU', 'HO', 'FN958870', 'ETV120n-1150-10520DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(110, 'PT. KRN', 'PT. LF SERVICE (LANDMARK)', 'PONDOK UNGU', 'HO', 'FN947530', 'ETV120n-1150-11510DZ', '2018', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(111, 'PT. KRN', 'PT. LF SERVICE (MAERSK)', 'CIBATU', 'HO', '82828095', 'ETR335d-1067-11354DZ', '2000', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(112, 'PT. KRN', 'PT. LF SERVICE JNJ', 'CIKARANG', 'HO', 'F5012124', 'EREMB220i-1150-670', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(113, 'PT. KRN', 'PT. LF SERVICE JNJ', 'CIKARANG', 'HO', 'F5002924', 'EFGMC320-1150-4800DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(114, 'PT. KRN', 'PT. LF SERVICE JNJ', 'CIKARANG', 'HO', 'F5024012', 'ETVMC320-1150-11510DZ', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(115, 'PT. KRN', 'PT. LF SERVICE JNJ', 'CIKARANG', 'HO', 'FN986243', 'ERE120n-115-6700', '2022', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(116, 'PT. KRN', 'PT. LF SERVICE JNJ', 'CIKARANG', 'HO', 'FN939580', 'ETV120n-1150-9020DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(117, 'PT. KRN', 'PT. LF SERVICE JNJ', 'CIKARANG', 'HO', 'FN947529', 'ETV120n-1150-11510DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(118, 'PT. KRN', 'PT. LF SERVICE JNJ', 'CIKARANG', 'HO', 'FN938624', 'EFG320n-1150-4800DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(119, 'PT. KRN', 'PT. MAERSK', 'MARUNDA', 'HO', '82830715', 'ETR335d-1067-11354DZ', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(120, 'PT. KRN', 'PT. MAERSK', 'MARUNDA', 'HO', 'F5016436', 'ETVMC320-1350-11510DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(121, 'PT. KRN', 'PT. MAERSK', 'MARUNDA', 'HO', '82830714', 'ETR335d-1067-11354DZ', '2000', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(122, 'PT. KRN', 'PT. MAERSK', 'MARUNDA', 'HO', '82830675', 'ETR335d-1067-11354DZ', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(123, 'PT. KRN', 'PT. MAERSK', 'MARUNDA', 'HO', '82830716', 'ETR335d-1067-11354DZ', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(124, 'PT. KRN', 'PT. MAERSK', 'MARUNDA', 'HO', '82830717', 'ETR335d-1067-11354DZ', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(125, 'PT. KRN', 'PT. MEKAR MULTI JASA', 'MARUNDA', 'HO', 'FN957223', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(126, 'PT. KRN', 'PT. MEKAR MULTI JASA', 'MARUNDA', 'HO', 'FN957231', 'ETV120n-1150-10520DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(127, 'PT. KRN', 'PT. MILTZER & MUENCH (DSV)', 'HALIM', 'HO', 'FN372628', 'EKX515K-1150-9500ZT', '2008', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(128, 'PT. KRN', 'PT. MILTZER & MUENCH (DSV)', 'HALIM', 'HO', 'FN920540', 'ETV116n-1150-9020DZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(129, 'PT. KRN', 'PT. MITRAPAK ERAMANDIRI', 'JABABEKA', 'HO', '91128257', 'ETV318-1350-10700DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(130, 'PT. KRN', 'PT. MULTI INDO MANDIRI ( MIM )', 'KARAWANG', 'HO', 'FN978055', 'ETV 120n - 1150 - 9620DZ', '2000', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(131, 'PT. KRN', 'PT. MULTI INDO MANDIRI ( MIM )', 'KARAWANG', 'HO', 'FN958873', 'ETV-120n-1150-11510DZ', '2019', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(132, 'PT. KRN', 'PT. NAKU LOGISTICS INDONESIA', 'CIBITUNG', 'HO', '98117065', 'ERE225-2400-6700', '2015', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(133, 'PT. KRN', 'PT. NAKU LOGISTICS INDONESIA', 'CIBITUNG', 'HO', 'FN962208', 'ERE120n-1150-6700', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(134, 'PT. KRN', 'PT. NUSA CENDANA HARUM', 'PENJARINGAN', 'HO', 'FN950228', 'ETV120n-1150-10520DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(135, 'PT. KRN', 'PT. NUSANTARA EXPRESS', 'PONDOK UNGU', 'HO', 'FN987322', 'ERE120n-2400-6700', '2021', 'RENTAL', '03/03/2026', 'PALET MOVER', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(136, 'PT. KRN', 'PT. NUSANTARA EXPRESS', 'PONDOK UNGU', 'HO', 'FN966912', 'ERE120n-2400-6700', '-', 'ACTIVE', '03/03/2026', 'Palet Mover', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(137, 'PT. KRN', 'PT. NUSANTARA EXPRESS', 'PONDOK UNGU', 'HO', 'FN975979', 'ERE120n-2400-6700', '-', 'ACTIVE', '03/03/2026', 'PALET MOVER', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(138, 'PT. KRN', 'PT. NUSANTARA EXPRESS', 'PONDOK UNGU', 'HO', 'FN987324', 'ERE120n-2400-6700', '-', 'ACTIVE', '03/03/2026', 'PALET MOVER', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(139, 'PT. KRN', 'PT. NUSANTARA EXPRESS', 'PONDOK UNGU', 'HO', 'FN975978', 'ERE120n-2400-6700', '-', 'ACTIVE', '03/03/2026', 'PALET MOVER', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(140, 'PT. KRN', 'PT. NUSANTARA EXPRESS', 'PONDOK UNGU', 'HO', '98147454', 'ERE225-2400-6700', '-', 'ACTIVE', '03/03/2026', 'PALET MOVER', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(141, 'PT. KRN', 'PT. NUSANTARA EXPRESS', 'PONDOK UNGU', 'HO', '98147452', 'ERE225-2400-6700', '-', 'ACTIVE', '03/03/2026', 'PALET MOVER', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(142, 'PT. KRN', 'PT. NUSANTARA EXPRESS (SHOPEE)', 'BOGOR', 'HO', 'FN966913', 'ERE120n-2400-6700', '2022', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(143, 'PT. KRN', 'PT. NUSANTARA EXPRESS (SHOPEE)', 'BOGOR', 'HO', 'FN987321', 'ERE120n-2400-6700', '2022', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(144, 'PT. KRN', 'PT. PAPANDAYAN COCOA INDUSTRIES', 'BANDUNG', 'HO', 'FN985338', 'EFGMB216kn-1150-6000DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(145, 'PT. KRN', 'PT. ROBERTET', 'KARAWANG', 'HO', 'F5011629', 'ETVMB216-1150-7700DZ', '2023', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(146, 'PT. KRN', 'PT. ROBERTET', 'KARAWANG', 'HO', 'F5017972', 'EFGMB216K-1150-4800DZ', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(147, 'PT. KRN', 'PT. SAMUDERA LOGISTICS SERVICES', 'DELTA MAS (LOGOS)', 'HO', 'F5016475', 'ETVMC320-1150-11510DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(148, 'PT. KRN', 'PT. SAMUDERA LOGISTICS SERVICES', 'DELTA MAS (LOGOS)', 'HO', 'F5002824', 'ETV120n-1150-10520DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(149, 'PT. KRN', 'PT. SAMUDERA LOGISTICS SERVICES', 'DELTA MAS (LOGOS)', 'HO', 'F5001123', 'EFGMC325-1100-4700DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(150, 'PT. KRN', 'PT. SAMUDERA LOGISTICS SERVICES', 'DELTA MAS (LOGOS)', 'HO', 'FN987101', 'ETV120n-1150-11510DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(151, 'PT. KRN', 'PT. SAMUDERA LOGISTICS SERVICES', 'DELTA MAS (LOGOS)', 'HO', 'FN987675', 'EFGMB216k-1150-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(152, 'PT. KRN', 'PT. SAMUDERA LOGISTICS SERVICES', 'DELTA MAS (PEPSICO)', 'HO', 'F5017966', 'EFGBB216k-1150-4800DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(153, 'PT. KRN', 'PT. SANGHIANG PERKASA', 'CIKAMPEK', 'HO', 'FN944680', 'ETV120n-1150-11510DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(154, 'PT. KRN', 'PT. SCHENKER LOGISTICS INDONESIA', 'PONDOK UNGU', 'HO', 'FN946898', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(155, 'PT. KRN', 'PT. SCHENKER LOGISTICS INDONESIA', 'MARUNDA', 'HO', 'FN970525', 'ETV116n-1150-9020DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(156, 'PT. KRN', 'PT. SCHENKER LOGISTICS INDONESIA', 'CENGKARENG', 'HO', 'FN969340', 'EFGMC320-1150-6500DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(157, 'PT. KRN', 'PT. SCHENKER LOGISTICS INDONESIA', 'CENGKARENG', 'HO', 'FN969341', 'EFGMC320-1150-6500DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(158, 'PT. KRN', 'PT. SCHENKER LOGISTICS INDONESIA', 'PONDOK UNGU', 'HO', 'FN957607', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(159, 'PT. KRN', 'PT. SCHENKER LOGISTICS INDONESIA', 'SENTUL', 'HO', 'FN938621', 'EFG320n-1150-4800DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(160, 'PT. KRN', 'PT. SCHENKER LOGISTICS INDONESIA', 'MARUNDA', 'HO', 'FN912197', 'EFG320n-1150-4800DZ', '2014', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(161, 'PT. KRN', 'PT. SCHENKER LOGISTICS INDONESIA', 'MARUNDA', 'HO', 'FN951530', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(162, 'PT. KRN', 'PT. SCHENKER LOGISTICS INDONESIA', 'SENTUL', 'HO', 'FN948800', 'ETV116n-1150-7700DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(163, 'PT. KRN', 'PT. SCHNEIDER', 'EJIP', 'HO', '91694326', 'EJE235i-1600-6700', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(164, 'PT. KRN', 'PT. SCHNEIDER', 'EJIP', 'HO', '95181380', 'EJE235i-1600-6700', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(165, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', '91613998', 'EJE235-1150-6700', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(166, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN587441', 'EKS210Z-1200-5500DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(167, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN954946', 'ETV116n-1150-9020DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(168, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', '91643580', 'EJE235-1400-6700', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(169, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'TREMBESI', 'HO', 'FN945716', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(170, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', '91654894', 'EJE235i-1600-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(171, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN947997', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(172, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN587444', 'EKS210Z-1200-5500DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(173, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN975571', 'EJC112ni-1150-2900ZT', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(174, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN947996', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(175, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'TREMBESI', 'HO', 'FN945718', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(176, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', '91653322', 'EJE235i-1600-6700', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(177, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN947995', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(178, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN972875', 'EJC112-1150-2900ZT', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(179, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'TREMBESI', 'HO', 'FN927647', 'ETV116n-1150-9020DZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(180, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN947998', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(181, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'F5001245', 'EFGMC330-1150-4700DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(182, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN951533', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(183, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN587442', 'EKS210Z-1200-5500DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(184, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN587443', 'EKS210Z-1200-5500DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(185, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN959594', 'EFG320n-1150-4800DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(186, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', '91654893', 'EJE235i-1600-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(187, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN510023', 'EFG430-1200-4700DZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(188, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'EJIP', 'HO', 'FN562118', 'EFG550-1150-3000ZT', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(189, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'TREMBESI', 'HO', 'FN945717', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(190, 'PT. KRN', 'PT. SCHNEIDER INDONESIA', 'CIKARANG', 'HO', '91694327', 'EJE 235i-1600-6700', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(191, 'PT. KRN', 'PT. SINAR NIAGA SEJAHTERA', 'CIRACAS', 'HO', 'FN968441', 'ERE120n-1150-6700', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(192, 'PT. KRN', 'PT. SINAR NIAGA SEJAHTERA', 'WALUYA', 'HO', 'F5002298', 'ETV116n-1150-9020DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(193, 'PT. KRN', 'PT. SINAR NIAGA SEJAHTERA', 'CIRACAS', 'HO', 'F5011564', 'ETVMC320-1150-10520DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(194, 'PT. KRN', 'PT. SINAR NIAGA SEJAHTERA', 'CIRACAS', 'HO', 'F5011513', 'ETVMC320-1150-10520DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(195, 'PT. KRN', 'PT. SINARMAS DISTRIBUSI NIAGA', 'PULO GADUNG', 'HO', 'FN987110', 'ETV120n-1150-11510DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(196, 'PT. KRN', 'PT. SMART', 'MARUNDA', 'HO', 'FN909654', 'ETV116n-1150-9020DZ', '2013', 'RENTAL', '26/01/2026', 'Reach Truck', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(197, 'PT. KRN', 'PT. SPIL TOLL', 'PONDOK UNGU', 'HO', 'FN978020', 'ETV116n-1150-9020DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(198, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5012253', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(199, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5012106', 'EREMB220-1150-670', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(200, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5011579', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(201, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5018155', 'ETVMC320-1150-9620DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(202, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'FN947527', 'ETV120n-1150-9620DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(203, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'FN986245', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(204, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5006382', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(205, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5006384', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(206, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'FN978022', 'ETV116n-1150-9020DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(207, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'FN946901', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(208, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012087', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(209, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'FN938699', 'ERE120n-1150-6700', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(210, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'F5011620', 'ETVMB216-1150-7700DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(211, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012108', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(212, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'FN970524', 'ETV116n-1150-9020DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(213, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5011595', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(214, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5023197', 'EREMB220-1150-670', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(215, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5012130', 'EREMB220-1150-6700', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(216, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'FN977513', 'ERE120n-1150-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(217, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'F5011621', 'ETVMB216-1150-7700DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(218, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'FN986244', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(219, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIKARANG', 'HO', 'F5030209', 'EREMB 220-1150-670', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(220, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012114', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(221, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIMAHI', 'HO', 'F5011578', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(222, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5012102', 'EREMB220-1150-670', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(223, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012072', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(224, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'FN987102', 'ETV120n-1150-11510DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(225, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5030216', 'ERE MB220-1150-670', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(226, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5011460', 'ETVMC320-1150-10520DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(227, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'FN986071', 'ERE120n-1150-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(228, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5012105', 'EREMB220-1150-670', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(229, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'F5011619', 'ETVMB216-1150-7700DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(230, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5012107', 'EREMB220-1150-670', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(231, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5012109', 'EREMB220-1150-670', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(232, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'FN982557', 'ETV116n-1150-7700DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(233, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'FN979509', 'ERE120n-1150-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(234, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'FN987506', 'ETV116n-1150-7700DZ', '2021', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(235, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5023454', 'ETV MB 216 GE 115-770DZ', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(236, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'FN978024', 'ETV116n-1150-9020DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(237, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5011603', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(238, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'FN940970', 'ERE120n-1150-6700', '2017', 'Back Up', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(239, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'FN953262', 'ERE 120 nG L 115-67', '2018', 'BACK UP', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(240, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIKOKOL', 'HO', 'F5031987', 'ETVMB216-1150-7700DZ', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(241, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PARUNG', 'HO', 'F5031966', 'EREMB220-1150-670', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(242, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012075', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(243, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIREBON', 'HO', 'F5018141', 'ETVMC320i-1150-9620DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(244, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5012073', 'EREMB-220-G115-87', '2023', '-', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(245, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PANGKAL PINANG', 'HO', 'F5007635', 'EFGMB216k-1150-6500DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(246, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5001061', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(247, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'FN987648', 'ETV120n-1150-6800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(248, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'FN958874', 'ETV120n-1150-11510DZ', '2019', 'Back Up', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(249, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIANJUR', 'HO', 'F5018150', 'ETVMC320-1150-9620DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(250, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5030217', 'ERE MB220-1150-670', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(251, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIMAHI', 'HO', 'F5011575', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(252, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'FN938697', 'ERE120n-1150-6700', '2017', 'Back Up', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(253, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5011601', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(254, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'F5026322', 'EREMB220-G115-67', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(255, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'FN977511', 'ERE120n-1150-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(256, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'FN978058', 'ETV116n-1150-7700DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(257, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5011602', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(258, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5001062', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(259, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIREBON', 'HO', 'F5011576', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(260, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5022653', 'EREMB220-1150-6700', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(261, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5030203', 'EREMB220-1150-670', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(262, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5006386', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(263, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012115', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(264, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5026323', 'ERE MB 220 - 1150 -670', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(265, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5018142', 'ETVMC320i-1150-9620DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(266, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIREBON', 'HO', 'F5023453', 'ETV MB 216 GE 115-902DZ', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(267, 'PT. EUROTRUK', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5020446', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(268, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5030215', 'ERE MB220-1150-670', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(269, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'FN986072', 'ERE120n-1150-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(270, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5011589', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(271, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5022654', 'EREMB220-1150-6700', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(272, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5011606', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(273, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'F5012125', 'EREMB220i-1150-670', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(274, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PARUNG', 'HO', 'F5018153', 'ETVMC320-1150-10520DZ', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(275, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'FN968423', 'ERE120n-1150-6700', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(276, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5020450', 'ETVMB216-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(277, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIKOKOL', 'HO', 'F5031991', 'ETVMB216-1150-7700DZ', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(278, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'FN927848', 'ETV116n-1150-7700DZ', '2016', 'BACKUP', '-', 'Reach Truck', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(279, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIPINANG', 'HO', 'F5002854', 'ETV120ni-1150-11510DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(280, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIANJUR', 'HO', 'F5018151', 'ETVMC320-1150-9620DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(281, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5023196', 'EREMB220-1150-670', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(282, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5012104', 'EREMB220-1150-670', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(283, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5023437', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(284, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'FN978057', 'ETV116n-1150-7700DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(285, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5020448', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(286, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'F5030208', 'EREMB 220-1150-670', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(287, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5011547', 'ETVMC320-1150-9620DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(288, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5006387', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(289, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012121', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(290, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'FN951534', 'ETV116n-1150-9020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(291, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIKOKOL', 'HO', 'F5031986', 'ETVMB216-1150-7700DZ', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(292, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5004497', 'ETV116n-1150-7700DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(293, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'F5011585', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(294, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PARUNG', 'HO', 'F5032964', 'ETVMB 216-1150-9020DZ', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(295, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', '98224442', 'ERE125i-1150-5400', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(296, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'F5011586', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(297, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'FN982515', 'EFGMB216kn-1150-6000DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(298, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5026317', 'EREMB 220 - 1150 - 670', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(299, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5011605', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(300, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIMAHI', 'HO', 'FN985432', 'ETV116n-1150-9020DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(301, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'FN962279', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(302, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'FN968421', 'ERE120n-1150-6700', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(303, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5003032', 'ERE120N-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(304, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'FN977514', 'ERE120n-1150-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(305, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'FN962278', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(306, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'F5011584', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(307, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5020447', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(308, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5030768', 'ETVMB216-1150-9020DZ', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(309, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', '98194006', 'ERE125-1150-6700', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(310, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5011598', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(311, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'FN986246', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(312, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'F5011599', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(313, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'FN979508', 'ERE120n-1150-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(314, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PANGKAL PINANG', 'HO', 'F5007636', 'EFGMB216k-1150-6500DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(315, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5011461', 'ETVMC320-1150-10520DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(316, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5020449', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(317, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'FN978023', 'ETV116n-1150-9020DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(318, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5012251', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(319, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIANJUR', 'HO', 'F5018152', 'ETVMC320-1150-9620DZ', '-', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(320, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012077', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(321, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIREBON', 'HO', 'F5023452', 'ETV MB 216 GE 115-902DZ', '2024', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(322, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'F5026321', 'EREMB220-G115-67', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(323, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'FN927467', 'ETV120n-1150-7700DZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(324, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5006378', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(325, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5012252', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(326, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5006388', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(327, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012071', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(328, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5011600', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(329, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5011594', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(330, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'JABABEKA', 'HO', 'FN977512', 'ERE120n-1150-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(331, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5026324', 'ERE MB220-1150-670', '2024', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(332, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BALARAJA', 'HO', 'F5011588', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(333, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'FN969098', 'EFGMB216kn-1150-6000DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(334, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5011604', 'ETVMB216-1150-9020DZ', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(335, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIBINONG', 'HO', 'F5012079', 'EREMB220-1150-6700', '2023', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(336, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'F5031965', 'EREMB220-G115-67', '2025', 'RENTAL', '-', 'Junior Truck', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(337, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CILEUNGSI', 'HO', 'F5031964', 'EREMB220-1150-6700', '2025', 'RENTAL', '-', 'Junior Truck', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(338, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5031963', 'EREMB220-1150-6700', '2025', 'RENTAL', '20/11/2025', 'JUNIOR TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(339, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5031962', 'EREMB220-1150-6700', '2025', 'RENTAL', '20/11/2025', 'JUNIOR TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(340, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PARUNG BOGOR', 'HO', 'F5024345', 'ETVMB216-1150-9620DZ', '2025', 'ACTIVE', '24/12/2025', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(341, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIREBON', 'HO', 'F5030224', 'EREMB220-1150-670', '2025', 'ACTIVE', '22/11/2025', 'PALLET MOVER', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(342, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIMAHI - BANDUNG', 'HO', 'F5011676', 'ETVMC320-1150-9020', '2025', 'ACTIVE', '10/12/2025', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(343, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIMAHI', 'HO', 'FN929196', 'ETV 120n GE 115-9020DZ', '2017', 'ACTIVE', '10/12/2025', 'REACH TRUCK', NULL, NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(344, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PARUNG', 'HO', 'F5031967', 'EREMB220-1150-670', '2025', 'ACTIVE', '21/11/2025', 'PALLET MOVER', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(345, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG 1', 'HO', 'F5025233', 'ETVMB216-GNE-1150-7700DZ', '2025', 'RENTAL', '-', 'Reach Truck', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(346, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG 1', 'HO', 'F5031989', 'ETVMB216-GNE-1150-7700DZ', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(347, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KARAWANG', 'HO', 'F5032961', 'ETVMB216-GE-1150-9020DZ', '2025', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(348, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5031973', 'EREMB220-1150-670', '2025', 'ACTIVE', '12/01/2026', 'ERE', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(349, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'BANDUNG', 'HO', 'F5031974', 'EREMB220-1150-670', '2025', 'RENTAL', '12/01/2026', 'ERE', NULL, NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(350, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIANJUR', 'HO', 'F5031972', 'EREMB220-1150-670', '2025', 'RENTAL', '13/01/2026', 'Pallet Mover', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(351, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KETAPANG KALIMANTAN BARAT', 'HO', 'F5035097', 'EFGMB216k-1150-6500DZ', '2025', 'ACTIVE', '12/02/2026', 'COUNTER BALANCE', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(352, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'KETAPANG KALIMANTAN BARAT', 'HO', 'F5035096', 'EFGMB216k-1150-6500DZ', '2025', 'ACTIVE', '12/02/2026', 'COUNTER BALANCE', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(353, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5036522', 'ETV MB 216', '2025', 'ACTIVE', '26/03/2026', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(354, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5035001', 'ETV MC 320', '2025', 'ACTIVE', '26/03/2026', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(355, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'PONTIANAK', 'HO', 'F5035002', 'ETV MC 320', '2025', 'ACTIVE', '26/03/2026', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(356, 'PT. KRN', 'PT. SUMBER ALFARIA TRIJAYA', 'CIMAHI', 'HO', 'FN944683', 'ETV 120n', '2018', 'ACTIVE', '-', 'REACH TRUCK', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(357, 'PT. KRN', 'PT. SUPERNOVA FLEXIBLE PACKAGING', 'MM2100', 'HO', 'FN588052', 'EKX516k-1200-8000DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(358, 'PT. KRN', 'PT. SUPERNOVA FLEXIBLE PACKAGING', 'MM2100', 'HO', 'FN980078', 'ERE120n-1400-6700', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(359, 'PT. KRN', 'PT. SUPERNOVA FLEXIBLE PACKAGING', 'MM2100', 'HO', 'FN671284', 'EKX516Ki-1200-8000DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(360, 'PT. KRN', 'PT. SUPERNOVA FLEXIBLE PACKAGING', 'MM2100', 'HO', 'FN648282', 'EKX516Ki-1200-8000DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(361, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'GUNUNG PUTRI', 'HO', 'FN975564', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(362, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'GUNUNG PUTRI', 'HO', 'FN975562', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(363, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'FN962258', 'EFGMC320-1100-4800DZ', '2011', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(364, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'FN954345', 'ETV120n-1350-11510DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(365, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'GUNUNG PUTRI', 'HO', 'FN975567', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(366, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'FN954346', 'ETV120n-1350-11510DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(367, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'FN975568', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(368, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'F5003146', 'ETV120n-1350-11510DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(369, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'FN975570', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(370, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'FN975566', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(371, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'FN975561', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(372, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'F5007029', 'ETV120n-1350-11510DZ', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(373, 'PT. EUROTRUK', 'PT. SYNGENTA INDONESIA', 'GUNUNG PUTRI', 'HO', 'FN975563', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(374, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'GUNUNG PUTRI', 'HO', 'FN912263', 'EFG320n-1150-6500DZ', '2014', 'Back Up', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(375, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'FN975565', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(376, 'PT. KRN', 'PT. SYNGENTA INDONESIA', 'CILEUNGSI', 'HO', 'FN975569', 'EFGMC320-1100-4800DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(377, 'PT. KRN', 'PT. TOPPAN PLASINDO', 'KARAWANG', 'HO', 'FN959542', 'ETV116n-1150-7700DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(378, 'PT. KRN', 'PT. TRITEGUH MANUNGGAL SEJATI', 'GUNUNG PUTRI', 'HO', 'FN979005', 'EFGMB216kn-1150-6500DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(379, 'PT. KRN', 'PT. TRITEGUH MANUNGGAL SEJATI', 'GUNUNG PUTRI', 'HO', 'FN962239', 'EFGMB216kn-1150-4800DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(380, 'PT. KRN', 'PT. TRITEGUH MANUNGGAL SEJATI', 'GUNUNG PUTRI', 'HO', '91125256', 'ETV320-1350-12020DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(381, 'PT. KRN', 'PT. TRITEGUH MANUNGGAL SEJATI', 'GUNUNG PUTRI', 'HO', 'FN966405', 'ERE120n-1150-6700', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(382, 'PT. KRN', 'PT. TRITEGUH MANUNGGAL SEJATI', 'GUNUNG PUTRI', 'HO', '91148072', 'ETM214-1150-7700DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(383, 'PT. KRN', 'PT. TROUW NUTRITION INDONESIA', 'MM2100', 'HO', 'FN535885', 'EFG425k-1150-4400DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(384, 'PT. KRN', 'PT. UNILEVER INDONESIA TBK', 'CIKARANG', 'HO', 'FN496325', 'DFG425-1150-3100ZT', '2015', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(385, 'PT. KRN', 'PT. UNILEVER INDONESIA TBK', 'CIKARANG', 'HO', 'FN497360', 'DFG425-1150-3100ZZ', '2015', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(386, 'PT. KRN', 'PT. UNILEVER INDONESIA TBK', 'CIKARANG', 'HO', 'FN519076', 'DFG425-1150-3100ZZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(387, 'PT. KRN', 'PT. UNILEVER INDONESIA TBK', 'CIKARANG', 'HO', 'FN519080', 'DFG425-1150-3100ZZ', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(388, 'PT. KRN', 'PT. UNILEVER INDONESIA TBK', 'CIKARANG', 'HO', 'FN459396', 'DFG425-1150-4700DZ', '2013', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(389, 'PT. KRN', 'PT. UNILEVER SAVOURY', 'CIKARANG', 'HO', 'FN944686', 'ERE120n-1150-6700', '2018', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(390, 'PT. KRN', 'PT. UNILEVER SAVOURY', 'CIKARANG', 'HO', 'FN962207', 'ERE120n-1150-6700', '2019', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(391, 'PT. KRN', 'PT. UNILEVER SAVOURY', 'CIKARANG', 'HO', 'FN938698', 'ERE120n-1150-6700', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(392, 'PT. KRN', 'PT. UNILEVER SAVOURY', 'CIKARANG', 'HO', '98106561', 'ERE120-1150-6700', '2015', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(393, 'PT. KRN', 'PT. UNILEVER SAVOURY', 'CIKARANG', 'HO', 'FN939402', 'EFG216kn-1150-4800DZ', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(394, 'PT. KRN', 'PT. UNILEVER SAVOURY', 'CIKARANG', 'HO', 'FN958133', 'EFG216kn', '2019', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(395, 'PT. KRN', 'PT. UNILEVER SAVOURY', 'CIKARANG', 'HO', 'FN953268', 'ERE120n-1150-6700', '2018', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(396, 'PT. KRN', 'PT. UNILEVER SAVOURY', 'CIKARANG', 'HO', '98106562', 'ERE120-1150-6700', '2015', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(397, 'PT. KRN', 'PT. UNIVERSAL TRACKTOR INDONESIA', 'MARUNDA', 'HO', '82829233', 'ETR335d-1067-11354DZ', '2023', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(398, 'PT. KRN', 'PT. WAHANA DUTA JAYA RUCIKA', 'KARAWANG', 'HO', 'F5006380', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(399, 'PT. KRN', 'PT. WAHANA DUTA JAYA RUCIKA', 'KARAWANG', 'HO', 'F5006379', 'ERE120n-1150-6700', '2022', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(400, 'PT. KRN', 'PT. WICAKSANA OVERSEAS INTERNATIONAL', 'PONDOK UNGU', 'HO', 'FN966905', 'ETV116n-1150-7700DZ', '2020', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(401, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN923308', 'ERE120n-1150-5300', '2016', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(402, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN954902', 'EFG216kn-1150-4800DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(403, 'PT. KRN', 'PT. YCH INDONESIA', 'JUNO', 'HO', 'FN923307', 'ERE120n-1150-5300', '2016', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(404, 'PT. KRN', 'PT. YCH INDONESIA', 'JUNO', 'HO', 'FN927505', 'ERE120n-1150-5300', '2016', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(405, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN929344', 'ERE120n-1150-6700', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(406, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', '82823800', 'ETR335d-1067-11400DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(407, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN502807', 'EFG430-1150-3100ZT', '2015', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(408, 'PT. KRN', 'PT. YCH INDONESIA', 'CIKARANG', 'HO', 'FN957236', 'ETV120n-1150-11510DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(409, 'PT. KRN', 'PT. YCH INDONESIA', 'LOGOS', 'HO', 'FN951221', 'ETV120n-1150-11510DZ', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(410, 'PT. KRN', 'PT. YCH INDONESIA', 'JUNO', 'HO', 'FN927504', 'ERE120n-1150-5300', '2016', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(411, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', '82822585', 'ETR335d-1067-11354DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(412, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN987422', 'EFGMC325-1150-4400DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(413, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', 'FN953267', 'ERE120n-1150-6700', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(414, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', 'FN954153', 'EFG320n-1150-4800DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(415, 'PT. KRN', 'PT. YCH INDONESIA', 'TJ PRIUK', 'HO', 'FN983556', 'EFGBB216k-1150-4800DZ', '2021', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:37:33'),
	(416, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN987421', 'EFGMC325-1150-4400DZ', '2021', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(417, 'PT. KRN', 'PT. YCH INDONESIA', 'JUNO', 'HO', 'FN927465', 'ETV120n-1150-9020DZ', '2016', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(418, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', '82823245', 'ETR335d-1067-11354DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(419, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN937202', 'ETV120n-1150-9620DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(420, 'PT. KRN', 'PT. YCH INDONESIA', 'JUNO', 'HO', 'FN929341', 'ERE120n-1150-6700', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(421, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN906663', 'ERE120NL-1150-6700', '2012', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(422, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', 'FN954152', 'EFG320n-1150-4800DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(423, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', 'FN948939', 'ETV116n-1150-9020DZ', '2018', 'BACKUP', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(424, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', 'FN953266', 'ERE120n-1150-6700', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(425, 'PT. KRN', 'PT. YCH INDONESIA', 'JUNO', 'HO', 'FN927447', 'ERE120n-1150-5300', '2016', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(426, 'PT.KRN', 'PT. YCH INDONESIA', 'JUNO', 'HO', 'FN937205', 'ETV120n-1150-11510DZ', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(427, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', 'FN953269', 'ERE120n-1150-6700', '2018', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(428, 'PT. KRN', 'PT. YCH INDONESIA', 'JUNO', 'HO', 'FN923309', 'ERE120n-1150-5300', '2016', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(429, 'PT. KRN', 'PT. YCH INDONESIA', 'FN928744', 'HO', 'FN928744', 'ETV120n-1150-9020DZ', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(430, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN536199', 'EFG430k-1150-4700DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(431, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN959600', 'EFG320n-1150-4800DZ', '2019', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(432, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN510009', 'EFG425k-1200-4700DZ', '2016', 'Back Up', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(433, 'PT. KRN', 'PT. YCH INDONESIA', 'TJ PRIUK', 'HO', 'FN912265', 'EFG320n-1150-4800DZ', '2014', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:36:23'),
	(434, 'PT. KRN', 'PT. YCH INDONESIA', 'JUNO', 'HO', 'FN944684', 'ETV120n-1150-10520DZ', '2018', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(435, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN359627', 'EFG320-1150-4800DZ', '2007', 'Back Up', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(436, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN906658', 'ERE120NL-1150-5300', '2012', 'Back Up', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(437, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN929195', 'ETV120n-1150-9020DZ', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(438, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN948935', 'ETV116n-1150-9020DZ', '2018', 'Back Up', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(439, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', 'FN906656', 'ERE120NL-1150-5300', '2012', 'Back Up', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(440, 'PT. KRN', 'PT. YCH INDONESIA', 'CIBITUNG', 'HO', '91114973', 'ETV325-1350-9110DZ', '2017', 'Rental', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(441, 'PT. KRN', 'PT. YCH INDONESIA', 'PONDOK UNGU', 'HO', '98080154', 'ERE120-1150-6700', '2013', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(442, 'PT. KRN', 'PT. YCH INDONESIA (3M)', 'PONDOK UNGU', 'HO', 'FN937203', 'ETV120n-1150-9620DZ', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(443, 'PT. KRN', 'PT. YCH INDONESIA (3M)', 'PONDOK UNGU', 'HO', 'FN940949', 'ETV120n-1150-9620DZ', '2018', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(444, 'PT. KRN', 'PT. YCH INDONESIA (3M)', 'PONDOK UNGU', 'HO', 'FN928745', 'ETV120N-1150-9620DZ', '2017', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41'),
	(445, 'PT. KRN', 'PT. YCH INDONESIA (3M)', 'PONDOK UNGU', 'HO', 'FN957244', 'ETV120N-1150-9620DZ', '2019', 'RENTAL', '-', '-', '-', NULL, '2026-05-30 00:21:41', '2026-05-30 00:21:41');

-- membuang struktur untuk table drrsakti_db.update_jobs
CREATE TABLE IF NOT EXISTS `update_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `branch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_mekanik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nopol` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `work_date` date DEFAULT NULL,
  `serial_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hour_meter` int DEFAULT NULL,
  `nomor_lambung` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `problem_date` date DEFAULT NULL,
  `rfu_date` date DEFAULT NULL,
  `lead_time_rfu` int DEFAULT NULL,
  `pm` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rm` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `problem` text COLLATE utf8mb4_unicode_ci,
  `action` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `update_jobs_user_id_foreign` (`user_id`),
  KEY `update_jobs_serial_number_index` (`serial_number`),
  KEY `update_jobs_customer_index` (`customer`),
  KEY `update_jobs_location_index` (`location`),
  CONSTRAINT `update_jobs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.update_jobs: ~0 rows (lebih kurang)

-- membuang struktur untuk table drrsakti_db.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nrpp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_user` enum('mekanik','koordinator','sect_head','super_admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mekanik',
  `branch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_nrpp_unique` (`nrpp`)
) ENGINE=InnoDB AUTO_INCREMENT=98981 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.users: ~27 rows (lebih kurang)
INSERT INTO `users` (`id`, `name`, `nrpp`, `password`, `status_user`, `branch`, `is_verified`, `verified_at`, `remember_token`, `created_at`, `updated_at`) VALUES
	(2357, 'JAYADI', '10022249', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:31:28'),
	(9386, 'EKO WAHYUDIN', '10023011', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:31:38'),
	(12430, 'YADI', '10003231', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'koordinator', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:31:49'),
	(15972, 'ILHAM FIRYANTO', '15021331', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 1, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(30659, 'EKO NURYANTO', '10020015', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:32:08'),
	(33515, 'AGUS SUPRIYANTO', '10023122', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:32:19'),
	(37036, 'M. IHSAN KAMIL', '10021081', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:32:29'),
	(37342, 'OGAN ELANG P', '10021092', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:32:41'),
	(45218, 'VIKRI IBNU S', '10019149', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:32:52'),
	(45980, 'DIMAS BANGGA K', '10022246', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:33:03'),
	(48229, 'DIDI ROHADI', '10010082', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:34:31'),
	(51585, 'SUPER ADMIN', '12345678', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'super_admin', 'HO', 1, '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
	(51882, 'SUTIYONO', '10000075', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'sect_head', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:34:44'),
	(55251, 'AZZIZULLAH', '10021084', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:34:58'),
	(55409, 'FIKRI FAHAR T', '13221095', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:35:12'),
	(59291, 'RATRI WISNU W', '10022251', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'koordinator', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:35:30'),
	(59717, 'ILHAM NAZARULLOH', '10022245', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:35:44'),
	(73775, 'IBNU MAULANA', '10025240', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:35:59'),
	(75726, 'BRIYAN SATYA H', '10020016', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:36:14'),
	(81246, 'APRI HANDOKO', '10019179', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:36:30'),
	(83065, 'ALPIN SUWANDA', '10022118', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:36:59'),
	(83353, 'DWIKI RINALDI', '10017136', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:37:11'),
	(89008, 'ATA SUPRIYATNA', '10026025', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:37:26'),
	(92598, 'INDRA FIRDAUS', '10020020', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:37:39'),
	(93657, 'DARYOTO', '10015107', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:37:52'),
	(94405, 'YULIANTO', '10022250', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:38:05'),
	(98980, 'M. DAFFA RAMADHAN', '10023131', '$2y$12$N4lxzVOnzjHM4o4EGwFYJe.dfPm9T4dcytbRvBycH5oYxaUkYRq72', 'mekanik', 'HO', 0, NULL, '', '0000-00-00 00:00:00', '2026-05-30 01:36:46');

-- membuang struktur untuk table drrsakti_db.user_subscriptions
CREATE TABLE IF NOT EXISTS `user_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `subscription_package_id` bigint unsigned NOT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `expired_at` timestamp NULL DEFAULT NULL,
  `status` enum('pending','active','expired','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_subscriptions_user_id_foreign` (`user_id`),
  KEY `user_subscriptions_subscription_package_id_foreign` (`subscription_package_id`),
  CONSTRAINT `user_subscriptions_subscription_package_id_foreign` FOREIGN KEY (`subscription_package_id`) REFERENCES `subscription_packages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel drrsakti_db.user_subscriptions: ~0 rows (lebih kurang)

-- membuang struktur untuk trigger drrsakti_db.trg_penarikans_after_insert_status
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `trg_penarikans_after_insert_status` AFTER INSERT ON `penarikans` FOR EACH ROW BEGIN
                UPDATE unit_assets
                SET status = 'DITARIK', updated_at = NOW()
                WHERE serial_number = NEW.serial_number;
            END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- membuang struktur untuk trigger drrsakti_db.trg_penarikans_after_update_status
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `trg_penarikans_after_update_status` AFTER UPDATE ON `penarikans` FOR EACH ROW BEGIN
                UPDATE unit_assets
                SET status = 'DITARIK', updated_at = NOW()
                WHERE serial_number = NEW.serial_number;
            END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
